package service;

import ui.MainGui;

public class Main {
    public static void main(String[] args) {
        // Chama a interface gráfica
        MainGui.main(args);
    }
}
