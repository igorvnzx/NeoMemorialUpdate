
package service;

public class PagamentoService {
    public void processarPagamento(String metodo) {
        System.out.println("Pagamento processado via " + metodo);
    }
}
